/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tareas2.prueba;

/**
 *
 * @author david
 * @matricula 2023-0243
 */
public class Tv {
    String MarcaTv;
    String TipoTV;
    int PulgadasTv;
    String ColorTv;

    public void MarcaTv() {
        System.out.println("La marca de la Tv es: " + MarcaTv);
    }

    public void Tipo() {
        System.out.println("El tipo de la Tv es: " + TipoTV);
    }

    public void Pulgadas() {
        System.out.println("El tamaño de la Tv es: " + PulgadasTv);
    }
    
        public void Color(){
        System.out.println("Color de la Tv: " + ColorTv + "\n");
    }
}
